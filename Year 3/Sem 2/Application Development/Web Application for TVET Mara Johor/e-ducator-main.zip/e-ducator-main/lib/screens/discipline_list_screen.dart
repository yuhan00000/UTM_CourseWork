// lib/screens/discipline_list_screen.dart
//
// Modul 2 — Halaman 1: Senarai Laporan Disiplin.
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/discipline_report.dart';
import '../providers/user_provider.dart';
import '../services/discipline_service.dart';
import '../theme/app_theme.dart';
import '../widgets/app_scaffold.dart';
import '../widgets/severity_badge.dart';
import 'discipline_form_screen.dart';

class DisciplineListScreen extends StatefulWidget {
  const DisciplineListScreen({super.key});

  @override
  State<DisciplineListScreen> createState() => _DisciplineListScreenState();
}

class _DisciplineListScreenState extends State<DisciplineListScreen> {
  final _service = DisciplineService();
  late Future<List<DisciplineReport>> _future;
  String _search = '';
  String _severityFilter = 'Semua';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<DisciplineReport>> _load() async {
    final user = context.read<UserProvider>().profile!;
    return _service.fetchReports(user);
  }

  void _refresh() => setState(() {
        _future = _load();
      });

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>().profile;
    final canCreate = user?.role == 'Lecturer';
    final canManage = user?.role == 'Admin';

    return AppScaffold(
      title: 'Laporan Disiplin',
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh),
          onPressed: _refresh,
        ),
      ],
      floatingActionButton: canCreate
          ? FloatingActionButton.extended(
              backgroundColor: AppTheme.teal,
              foregroundColor: AppTheme.navy,
              onPressed: () async {
                final ok = await Navigator.pushNamed(context, '/discipline-form');
                if (ok == true) _refresh();
              },
              icon: const Icon(Icons.add),
              label: const Text('Laporan Baru'),
            )
          : null,
      body: Column(
        children: [
          _filterBar(),
          Expanded(
            child: FutureBuilder<List<DisciplineReport>>(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snap.hasError) {
                  return Center(child: Text('Ralat: ${snap.error}'));
                }
                final reports = (snap.data ?? const []).where(_match).toList();
                if (reports.isEmpty) {
                  return const Center(
                    child: Text('Tiada laporan disiplin.',
                        style: TextStyle(color: AppTheme.textMuted)),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: reports.length,
                  itemBuilder: (_, i) => _reportCard(reports[i], canManage: canManage),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  bool _match(DisciplineReport r) {
    if (_severityFilter != 'Semua' && r.severity != _severityFilter) return false;
    if (_search.isEmpty) return true;
    final q = _search.toLowerCase();
    return (r.studentName ?? '').toLowerCase().contains(q) ||
        r.issueType.toLowerCase().contains(q) ||
        (r.subjectCode ?? '').toLowerCase().contains(q) ||
        (r.kelas ?? '').toLowerCase().contains(q);
  }

  Widget _filterBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(12),
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          SizedBox(
            width: 320,
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Cari pelajar, kursus atau jenis isu...',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => _search = v),
            ),
          ),
          SizedBox(
            width: 200,
            child: DropdownButtonFormField<String>(
              initialValue: _severityFilter,
              decoration: const InputDecoration(labelText: 'Tahap Keseriusan'),
              items: ['Semua', ...kSeverityLevels]
                  .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                  .toList(),
              onChanged: (v) =>
                  setState(() => _severityFilter = v ?? 'Semua'),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(DisciplineReport r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Laporan?'),
        content: Text(
            'Anda pasti mahu memadam laporan untuk ${r.studentName ?? r.studentId}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (ok != true || r.id == null) return;
    try {
      await _service.deleteReport(r.id!);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Laporan dipadam.')),
      );
      _refresh();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ralat: $e')),
      );
    }
  }

  Widget _reportCard(DisciplineReport r, {required bool canManage}) {
    final df = DateFormat('d MMM yyyy', 'ms');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    r.studentName ?? r.studentId,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: AppTheme.navy,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${r.programId ?? "-"} • ${r.kelas ?? "-"} • ${r.subjectCode ?? "-"} • ${r.issueType}',
                    style: const TextStyle(color: AppTheme.textMuted),
                  ),
                  const SizedBox(height: 8),
                  if ((r.notes ?? '').isNotEmpty)
                    Text(
                      r.notes!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  const SizedBox(height: 8),
                  Text(
                    'Dilaporkan oleh ${r.reporterName ?? "-"} • '
                    '${r.createdAt != null ? df.format(r.createdAt!) : "-"}',
                    style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                SeverityBadge(severity: r.severity),
                if (canManage) ...[
                  const SizedBox(height: 8),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit_outlined, size: 20),
                        color: AppTheme.teal,
                        tooltip: 'Edit',
                        visualDensity: VisualDensity.compact,
                        onPressed: () async {
                          final ok = await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DisciplineFormScreen(report: r),
                            ),
                          );
                          if (ok == true) _refresh();
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, size: 20),
                        color: Colors.redAccent,
                        tooltip: 'Padam',
                        visualDensity: VisualDensity.compact,
                        onPressed: () => _confirmDelete(r),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
